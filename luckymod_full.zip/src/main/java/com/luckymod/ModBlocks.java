package com.luckymod;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;

public class ModBlocks {

    public static final Block DIAMOND_LUCKY_BLOCK = register("diamond_lucky_block",
            BlockBehaviour.Properties.of()
                    .mapColor(MapColor.DIAMOND)
                    .strength(2.0f, 6.0f)
                    .sound(SoundType.AMETHYST));

    public static final Block NETHERITE_LUCKY_BLOCK = register("netherite_lucky_block",
            BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_BLACK)
                    .strength(3.0f, 12.0f)
                    .sound(SoundType.NETHERITE_BLOCK));

    private static Block register(String name, BlockBehaviour.Properties props) {
        Identifier id = Identifier.fromNamespaceAndPath(LuckyMod.MOD_ID, name);

        ResourceKey<Block> blockKey = ResourceKey.create(Registries.BLOCK, id);
        Block block = new Block(props.setId(blockKey));
        Registry.register(BuiltInRegistries.BLOCK, blockKey, block);

        ResourceKey<Item> itemKey = ResourceKey.create(Registries.ITEM, id);
        BlockItem item = new BlockItem(block,
                new Item.Properties().setId(itemKey).useBlockDescriptionPrefix());
        Registry.register(BuiltInRegistries.ITEM, itemKey, item);

        return block;
    }

    public static void init() {
        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.BUILDING_BLOCKS).register(entries -> {
            entries.accept(DIAMOND_LUCKY_BLOCK);
            entries.accept(NETHERITE_LUCKY_BLOCK);
        });
    }
}
