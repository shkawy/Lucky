package com.luckymod;

import java.util.function.UnaryOperator;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ToolMaterial;

public class ModItems {
    public static final Item FIRE_SWORD = register("fire_sword",
            p -> p.sword(ToolMaterial.NETHERITE, 8.0f, -2.4f).fireResistant());

    private static Item register(String name, UnaryOperator<Item.Properties> f) {
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM,
                Identifier.fromNamespaceAndPath(LuckyMod.MOD_ID, name));
        Item item = new Item(f.apply(new Item.Properties().setId(key)));
        return Registry.register(BuiltInRegistries.ITEM, key, item);
    }

    public static void init() {
        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.COMBAT)
                .register(e -> e.accept(FIRE_SWORD));
    }
}
