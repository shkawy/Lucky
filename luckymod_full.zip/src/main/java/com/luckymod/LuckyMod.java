package com.luckymod;

import net.fabricmc.api.ModInitializer;

public class LuckyMod implements ModInitializer {
    public static final String MOD_ID = "luckymod";

    @Override
    public void onInitialize() {
        ModBlocks.init();
        ModItems.init();
        SkyIsland.init();
    }
}
