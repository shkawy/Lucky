package com.luckymod;

import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

public class SkyIsland {
    private static final String TAG = "sky_island_done";

    public static void init() {
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ServerPlayer player = handler.getPlayer();
            if (player.getTags().contains(TAG)) return;
            player.addTag(TAG);

            String id = player.getStringUUID();
            run(server, "fill -3 98 -3 3 99 3 dirt");
            run(server, "fill -3 100 -3 3 100 3 grass_block");
            run(server, "place feature minecraft:oak 0 101 2");
            run(server, "setblock 2 101 -2 chest[facing=south]{Items:["
                    + "{Slot:0,id:\"minecraft:lava_bucket\",count:1},"
                    + "{Slot:1,id:\"minecraft:ice\",count:2},"
                    + "{Slot:2,id:\"minecraft:bread\",count:16},"
                    + "{Slot:3,id:\"minecraft:melon_seeds\",count:1},"
                    + "{Slot:4,id:\"minecraft:bone_meal\",count:8}]}");
            run(server, "tp " + id + " 0.5 101 0.5");
            run(server, "spawnpoint " + id + " 0 101 0");
        });
    }

    private static void run(MinecraftServer server, String command) {
        server.getCommands().performPrefixedCommand(server.createCommandSourceStack(), command);
    }
}
