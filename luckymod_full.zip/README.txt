Build on phone (no PC): upload this whole folder to a GitHub repo, open Actions tab, run "build",
download the artifact "luckymod-jar". Unzip it -> luckymod-1.0.0.jar. Put it in mods folder with Fabric API.
If the build fails, copy exact versions from fabricmc.net/develop into gradle.properties / build.gradle.
